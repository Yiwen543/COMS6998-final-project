"""Read-only candidate publication inventory; never stage/write Git objects."""
from pathlib import Path
from collections import Counter
import gzip,hashlib,io,json,os,re,stat,subprocess,time,unicodedata,zipfile
ROOT=Path('/Users/yiwenchen/Desktop/COMS6998/ai_for_chip_design_project/COMS6998-final-project')
OUT=Path('/tmp/coms6998-bc-publication-2026-11-06')
ENV=dict(os.environ,GIT_OPTIONAL_LOCKS='0')
def git(*args,input=None):return subprocess.run(['git','-c','core.fsmonitor=false',*args],cwd=ROOT,env=ENV,input=input,capture_output=True,check=True).stdout
def write(name,value):
 with (OUT/name).open('x') as f:f.write(json.dumps(value,indent=2)+'\n')
DIRS=['test2/g1_v4/','test2/g1_v5/','test2/g1_v5b/','test2/retest_v1/','test2/retest_v2/','test2/retest_v3/']
DIRS += ['test2/results/'+name+'/' for name in ['g1-qualification-v4','g1-qualification-v5','g1-qualification-v5b','controller-done-bc-retest-preparation-v1','controller-done-bc-retest-preparation-v2','controller-done-bc-retest-preparation-v3','controller-done-bc-retest-v3','controller-done-bc-retest-v3-supervision']]
DIRS += ['docs/audits/'+name+'/' for name in ['producer_test2_g1_C02_2026-11-06','producer_test2_g1_E03_2026-11-06','producer_test2_g1_E04_2026-11-06','producer_test2_g1_R04_2026-11-06','producer_test2_g1_R05_2026-11-06','producer_test2_g1_R05B_2026-11-06','producer_test2_bc_retest_R01_2026-11-06','producer_test2_bc_retest_R02_2026-11-06','producer_test2_bc_retest_R03_2026-11-06','producer_test2_bc_retest_E01_2026-11-06','producer_test2_next_stage_readonly_2026-11-06']]
DIRS += ['docs/audits/agent_bridge_2026-11-06/'+name+'/' for name in ['BC_retest_v1','G1_qualification_v1','P14_g1_startup_preflight','P15_g1_R04_execution','P16_g1_preflight','P17_g1_completed_execution','P18_bc_retest_preflight']]
EXACT={'test2/configs/g1_qualification_registration_v4.json','test2/configs/g1_qualification_registration_v5.json','test2/configs/g1_qualification_registration_v5b.json','test2/configs/controller_done_bc_retest_v1.json','test2/configs/controller_done_bc_retest_v2.json','test2/configs/controller_done_bc_retest_v3.json'}
EXACT |= {'docs/audits/producer_test2_bc_retest_'+name+'_2026-11-06-final-verification.json' for name in ['R02','R03','E01']}
DEFER={'docs/HANDOFF.md','docs/PROJECT_STATUS.md','docs/audits/agent_bridge_2026-11-06/state.json','docs/audits/agent_bridge_2026-11-06/journal.jsonl'}

def private_name(name):
 parts=Path(name).parts
 return ('build' in parts and 'private' in parts and parts.index('private')>parts.index('build')) or any(x=='.env' or x.startswith('.env.') or x in ['id_rsa','id_ed25519','midterm-openai-key','anthropic-crosscheck-key','credentials.csv','credentials.json'] for x in parts)
def excluded_cache(name):return any(x in ['.venv','venv','__pycache__','.pytest_cache','.mypy_cache','.ruff_cache','node_modules','.git','.DS_Store'] for x in Path(name).parts)

def rows_now():
 raw=git('status','--porcelain=v1','-z','--untracked-files=all','--no-renames');rows=[]
 for item in raw.split(b'\0'):
  if item:rows.append(dict(status=item[:2].decode(),path=item[3:].decode()))
 return rows

# No matching values or contexts are emitted to any artifact.
RULES={
 'OPENAI_OR_ANTHROPIC_TOKEN':rb'\bsk-(?:(?:proj|svcacct|ant)-)?[A-Za-z0-9_-]{20,}',
 'GITHUB_TOKEN':rb'\b(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})',
 'AWS_ACCESS_KEY':rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b',
 'GOOGLE_API_KEY':rb'\bAIza[A-Za-z0-9_-]{30,}',
 'SLACK_TOKEN':rb'\bxox[baprs]-[A-Za-z0-9-]{20,}',
 'JWT_TOKEN':rb'\beyJ[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{12,}',
 'PRIVATE_KEY_PEM':rb'-----BEGIN (?:RSA |EC |DSA |OPENSSH |ENCRYPTED )?PRIVATE KEY-----',
 'PGP_PRIVATE_KEY':rb'-----BEGIN PGP PRIVATE KEY BLOCK-----',
 'URL_PASSWORD':rb'\bhttps?://[^\s/:@\x22\x27<>]+:[^\s/@\x22\x27<>]+@',
 'BEARER_TOKEN':rb'\bBearer[ \t]+[A-Za-z0-9_.-]{12,}',
 'LITERAL_SECRET_ASSIGNMENT':rb'''(?im)\b(?:[A-Z][A-Z0-9_]*_)?(?:API_KEY|ACCESS_TOKEN|AUTH_TOKEN|PASSWORD|PASSWD|CLIENT_SECRET|SECRET_ACCESS_KEY|AUTHORIZATION)[\x22\x27]?\s*[:=]\s*[\x22\x27][^\x22\x27\r\n]{8,}[\x22\x27]'''
}
COMPILED={k:re.compile(v) for k,v in RULES.items()}
MAX_EXPANDED=64*1024*1024
findings=[];archive_issues=[];archive_stats=Counter();scanned_bytes=0

def scan_bytes(data,path,member=None,depth=0):
 global scanned_bytes
 scanned_bytes+=len(data)
 for rule,regex in COMPILED.items():
  for match in regex.finditer(data):
   findings.append(dict(rule=rule,path=path,archive_member=member,line=data.count(b'\n',0,match.start())+1,byte_start=match.start(),byte_end=match.end(),classification='UNRESOLVED_NEEDS_REVIEW',matching_value_recorded=False))
 if depth>=3:
  if data.startswith(b'\x1f\x8b') or data.startswith(b'PK\x03\x04'):archive_issues.append(dict(rule='NESTED_ARCHIVE_DEPTH_LIMIT',path=path,archive_member=member))
  return
 if data.startswith(b'\x1f\x8b'):
  archive_stats['gzip_containers']+=1
  try:
   with gzip.GzipFile(fileobj=io.BytesIO(data)) as stream:plain=stream.read(MAX_EXPANDED+1)
   if len(plain)>MAX_EXPANDED:archive_issues.append(dict(rule='GZIP_EXPANSION_LIMIT',path=path,archive_member=member));return
   archive_stats['gzip_expanded_bytes']+=len(plain);scan_bytes(plain,path,(member+'!' if member else '')+'<gzip>',depth+1)
  except (OSError,EOFError,ValueError):archive_issues.append(dict(rule='GZIP_UNREADABLE',path=path,archive_member=member))
 elif data.startswith(b'PK\x03\x04') or data.startswith(b'PK\x05\x06'):
  archive_stats['zip_containers']+=1
  try:
   with zipfile.ZipFile(io.BytesIO(data)) as archive:
    total=0
    if len(archive.infolist())>5000:archive_issues.append(dict(rule='ZIP_MEMBER_COUNT_LIMIT',path=path));return
    for item in archive.infolist():
     if item.is_dir():continue
     name=(member+'!' if member else '')+item.filename
     if private_name(item.filename):archive_issues.append(dict(rule='ZIP_PRIVATE_CREDENTIAL_ENTRY_NOT_READ',path=path,archive_member=name));continue
     if item.flag_bits&1 or item.file_size>MAX_EXPANDED or total+item.file_size>256*1024*1024:archive_issues.append(dict(rule='ZIP_ENCRYPTED_OR_EXPANSION_LIMIT',path=path,archive_member=name));continue
     plain=archive.read(item);total+=len(plain);archive_stats['zip_members']+=1;archive_stats['zip_expanded_bytes']+=len(plain);scan_bytes(plain,path,name,depth+1)
  except (OSError,ValueError,zipfile.BadZipFile,RuntimeError):archive_issues.append(dict(rule='ZIP_UNREADABLE',path=path,archive_member=member))

start=time.monotonic();rows=rows_now();head=git('rev-parse','HEAD').decode().strip();entries_before=git('ls-files','--stage','-z');raw_index=Path(git('rev-parse','--git-path','index').decode().strip());raw_index=raw_index if raw_index.is_absolute() else ROOT/raw_index;raw_index_before=hashlib.sha256(raw_index.read_bytes()).hexdigest()
assert head=='2de33e981d2fffc9739d2ca049fbae1774de1aad' and not git('diff','--cached','--name-only')
selected=[];deferred=[];out_of_scope=[];blocked=[]
for row in rows:
 name=row['path']
 if name in DEFER or name.startswith('docs/audits/agent_bridge_2026-11-06/P19'):
  deferred.append(dict(row,reason='Mutable root coordination/shared docs or ongoing P19;final snapshot not fixed'));continue
 if private_name(name) or excluded_cache(name):blocked.append(dict(row,reason='Credential/environment/cache excluded without content read'));continue
 if name in EXACT or any(name.startswith(prefix) for prefix in DIRS):selected.append(row)
 else:out_of_scope.append(dict(row,reason='Not in explicitly enumerated completed-task scope;preserve local'))

attrs_raw=git('check-attr','--all','-z','--stdin',input=b''.join(r['path'].encode()+b'\0' for r in selected));parts=attrs_raw.split(b'\0');attrs=[]
for i in range(0,len(parts)-2,3):attrs.append(dict(path=parts[i].decode(),attribute=parts[i+1].decode(),value=parts[i+2].decode()))
transforms=[r for r in attrs if r['attribute'] in ['filter','working-tree-encoding','eol','ident','text'] and r['value'] not in ['unspecified','unset']]
manifest=[];symlinks=[];races=[];oversized=[]
for row in selected:
 name=row['path'];path=ROOT/name
 if any(parent.is_symlink() for parent in path.parents if parent!=ROOT and ROOT in parent.parents):blocked.append(dict(row,reason='Symlink parent;contents not read'));continue
 st=path.lstat()
 if stat.S_ISLNK(st.st_mode):
  data=os.readlink(path).encode();mode='120000';symlinks.append(dict(path=name,mode=mode,bytes=len(data),target_content_not_printed=True))
 elif stat.S_ISREG(st.st_mode):
  data=path.read_bytes();mode='100755' if st.st_mode&0o111 else '100644'
 else:blocked.append(dict(row,reason='Unsupported non-regular Git path'));continue
 after=path.lstat()
 if (st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns)!=(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns):races.append(name)
 if len(data)>100*1024*1024:oversized.append(name)
 digest=hashlib.sha256(data).hexdigest();blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 manifest.append(dict(path=name,status=row['status'],mode=mode,bytes=len(data),sha256=digest,git_blob_oid=blob,git_blob_oid_basis='Raw bytes;requires clean attributes/filters gate',worktree_mtime_ns=st.st_mtime_ns))
 scan_bytes(data,name)

# Group by research stage, then cap each explicit pathspec batch at10000.
def order(row):
 p=row['path'];group=0 if ('g1_' in p or 'g1-' in p or '/G1_' in p or '/P14_' in p or '/P15_' in p or '/P16_' in p or '/P17_' in p) else 1 if ('retest_v1' in p or 'preparation-v1' in p or 'retest_R01_' in p or 'bc_retest_v1.json' in p) else 2
 return group,p
manifest.sort(key=order);batches=[]
for offset in range(0,len(manifest),10000):
 batch=manifest[offset:offset+10000];number=len(batches)+1;path=OUT/f'batch-{number:02d}.paths0'
 with path.open('xb') as stream:stream.write(b''.join(row['path'].encode()+b'\0' for row in batch))
 batches.append(dict(batch=number,paths_file=path.name,count=len(batch),bytes=sum(row['bytes'] for row in batch),pathspec_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),first_path=batch[0]['path'],last_path=batch[-1]['path'],execute_authorized_by_this_plan=False))
entries_after=git('ls-files','--stage','-z');raw_index_after=hashlib.sha256(raw_index.read_bytes()).hexdigest();assert entries_before==entries_after and raw_index_before==raw_index_after
write('candidate-manifest.json',dict(status='PROVISIONAL_READ_ONLY_NOT_APPROVED_FOR_GIT_WRITE',HEAD=head,object_format='sha1',file_count=len(manifest),bytes=sum(row['bytes'] for row in manifest),files=manifest,source_scope='Explicit completed G1/R01/R02/R03/P18/E01 plus task runtime/config/evidence;not full workspace mirror',deferred_finalization=deferred,excluded_or_blocked=blocked,out_of_scope=out_of_scope,forbidden_credential_path='build/private/midterm-openai-key',credential_ignored=git('check-ignore','--','build/private/midterm-openai-key').decode().strip(),credential_file_content_read_or_hashed=False,read_only_index_entries_sha256=hashlib.sha256(entries_after).hexdigest(),raw_index_unchanged_during_this_scan=True))
write('sensitive-scan.json',dict(status='MATCHES_OR_BLOCKERS_NEED_REVIEW' if findings or archive_issues or blocked or transforms or races or oversized or symlinks else 'NO_MATCHES_WITH_DECLARED_RULE_LIMITS',rules=[dict(id=k,pattern=v.decode()) for k,v in RULES.items()],candidate_paths=len(manifest),bytes_including_expansions_scanned=scanned_bytes,findings=findings,archive_issues=archive_issues,archive_stats=dict(archive_stats),git_attributes=attrs,content_transform_attributes=transforms,symlinks=symlinks,unstable_files=races,over100MiB_files=oversized,excluded_private_or_cache_paths=blocked,credential_file_read_or_hashed=False,matching_values_printed_or_recorded=False,limits=['Pattern scan cannot prove absence of every arbitrary secret;unknown findings block publication.','All matching values omitted;synthetic fixture exceptions require exact source/identity review.','No ignored credential/environment/cache files read;no Git staging/objects written.']))
write('batch-plan.json',dict(status='PROPOSED_ONLY_PENDING_P19_ROOT_REVIEW_AND_REFRESH',batches=batches,total_paths=len(manifest),total_bytes=sum(r['bytes'] for r in manifest),max_batch_paths=10000,never_use_add_A_or_force_add=True,staging_method_for_later_review_only='Explicit --pathspec-from-file batch-NN.paths0 --pathspec-file-nul;never execute during this preparation',pending=['P19 finalreview/closure files and mutable docs/state must be separately admitted,scanned,hashed after completion.','Fresh status/source hash/index/remote checks required before Git writes.','Any new paths,symlinks,attributes/hooks/filters or scanner findings require root review.']))
summary=dict(status='PROVISIONAL_PLAN_WRITTEN',actual_changed_paths=len(rows),selected_paths=len(manifest),selected_bytes=sum(r['bytes'] for r in manifest),largest_files=sorted([{k:r[k] for k in ['path','bytes','mode']} for r in manifest],key=lambda r:r['bytes'],reverse=True)[:10],deferred_count=len(deferred),out_of_scope_count=len(out_of_scope),blocked_count=len(blocked),scanner_findings=len(findings),archive_issues=len(archive_issues),archive_stats=dict(archive_stats),symlinks=len(symlinks),transform_attrs=len(transforms),unstable_files=len(races),batches=[dict(batch=b['batch'],count=b['count'],bytes=b['bytes']) for b in batches],elapsed_seconds=time.monotonic()-start,Git_writes=0,index_raw_and_entries_unchanged=True,credential_content_read_or_hashed=False)
write('summary.json',summary);print(json.dumps(summary,indent=2))
