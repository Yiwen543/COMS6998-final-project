(* keep *) wire [4:0] loop_sample = {active, valid_lost, data_changed, last_changed, user_changed};
always @* stall_reached: cover(active);
always @* check_0: assert(!(active && valid_lost));
always @* check_1: assert(!(active && data_changed));
always @* check_2: assert(!(active && user_changed));
