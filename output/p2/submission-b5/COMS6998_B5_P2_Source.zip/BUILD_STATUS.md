# B5 P2 submission source — PDF export blocked

Current status: **final TeX source compiled successfully through the desktop
compiler interface; PDF export, page count and two-page visual validation are
not completed. Do not submit this as a finished PDF deliverable.**

Project: B5. Chiyu Chen (cc5583), Mingyuan Zheng (mz3143), Yiwen Chen (yc4653).
The official template README confirms November 9, 2026, 11:59 PM ET, two pages
excluding references, with figures/tables inside the page limit.

## Files

- `latex/main.tex`: editable English report using the official four sections,
  10pt two-column US Letter document class and unchanged supplied IEEEtran.cls.
- `latex/images/pilot-bc.png`: paper-sized version of the same saved pilot data.
  Its standalone image was visually checked; this is not PDF layout validation.
- `official-template/coms6998-project-p2.zip`: exact downloaded course archive.
  Extracted originals and `source.json` preserve its URL, hash and instructions.
- `MILESTONE2-reviewed-source.md`: exact copy of the previously reviewed Markdown.
  Original Markdown/data/figure and the historical material review are unchanged.
- `compile-diagnostics.json`: actual interface success messages, failed local
  export attempts, and explicit unknown page/overflow status.
- `COMS6998_B5_P2_Source.zip`: portable source project; it contains no final PDF.

## Concrete blocker

The official `compile_latex_document` interface returned success for the initial
and final sources, but explicitly does not export a PDF and returned no page
count or overflow diagnostics. The Mac is locked, so native GUI export is
unavailable. No repeated locked-interface attempts or unlock request was made.

One reasonable direct export path used the Tectonic already bundled with the
desktop app. Its default cache creation was denied by the writable-root policy.
A bounded retry with project-local cache and `--only-cached` could not find the
required bundle. No new software/packages were installed and no further cache
search/download was attempted. This does not contradict the separate interface's
success, but it leaves no accessible exported PDF to count/render.

## Resume after the Mac is unlocked

1. Open `latex/` or `latex/main.tex` in the Codex LaTeX editor. Compile the saved
   main document; keep the official class, font size, columns and margins.
2. Use the editor's PDF export/download control to save
   `COMS6998_B5_P2.pdf` in this directory. The exact control could not be inspected
   while locked. Do not claim two pages from source length or compiler success.
3. Check the real file with `pdfinfo`. If it exceeds two pages, shorten prose
   while retaining the raw denominator, unknowns, audit recovery, and feedback
   gap. Recompile and export; do not shrink the official template formatting.
4. Render both actual pages with `pdftoppm`, inspect text/figure/captions for
   clipping and overflow, then record exact hashes and page count. Only after
   this step is the two-page PDF deliverable complete. Route the result to the
   existing reviewer for the requested small template/content check.

No research, generation/count/Claude call, key access, installation or Git index
mutation is part of that export. Actual instructor/TA technical feedback remains
missing; the report marks its response pending. I2C remains a proposed next
study; new ABI/hidden inputs/mutants and G1 qualification are not claimed done.
